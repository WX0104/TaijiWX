package com.example.bean;

public class YetAnotherBean {
	private String name ="YetAnotherBean";

	public String getName() {
		return name;
	}

	public void setName(String name) {
		this.name = name;
	}

}
